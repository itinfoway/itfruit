<?php

defined('BASEPATH') OR exit('No direct script access allowed');
require_once APPPATH . "core/Controller.php";

/**
 * Description of Setting
 * https://itinfoway.com
 * @author Admin
 */
class Contacts extends Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model("Contact_model");
    }

   
     public function add() {
        if ($this->input->server('REQUEST_METHOD') == 'POST') {
            $capArray = $this->input->post();
            $data = $this->Contact_model->add($capArray);
            print_r($data);
            if (!empty($data)) {
                redirect("admin/Contacts/add");
            } else {
                redirect("admin/Contacts/add");
            }
        }
        $this->display('add');
    }

   

}


