<?php
/**
 * Description of english_lang
 * https://itinfoway.com
 * @author Admin
 */
$lang["btn_add"] = 'Add';
$lang["btn_list"] = 'List';
$lang["btn_save"] = 'Save';
$lang["btn_reset"] = 'Cancel';
$lang["action"] = 'Action';


$lang["faq_head"] = 'FAQ';
$lang["faq_input_qus_emsg"] = 'You have not given a 5-300 chars';
$lang["faq_input_ans_emsg"] = 'You have not given a min 5 chars';
$lang["faq_input_qus_plac"] = 'Enter Questions';
$lang["faq_input_ans_plac"] = 'Enter Answers';
$lang["faq_qus_hed"] = 'Questions';
$lang["faq_ans_hed"] = 'Answers';


$lang["Vitamin_head"] = 'Vitamin';
$lang["Vitamin_input_vname_emsg"] = 'You have not given a 5-50 chars';
$lang["Vitamin_input_vname_plac"] = 'Enter Vitamin Name';
$lang["Vitamin_vname_hed"] = 'Vitamin Name';

// Contacts Form
$lang["contact_head"] = 'Contact';
$lang["contact_date"] = 'Date';
$lang["contact_input_date_emsg"] = 'Please enter date';
$lang["contact_input_date_plac"] = 'Enter  Date';
$lang["contact_name"] = 'Name';
$lang["contact_input_name_emsg"] = 'You have not given a min 10 chars';
$lang["contact_input_name_plac"] = 'Enter  Name';
$lang["contact_email"] = 'Email';
$lang["contact_input_email_emsg"] = 'Please enter email';
$lang["contact_input_email_plac"] = 'Enter  Email';
$lang["contact_no"] = 'Contact Number';
$lang["contact_input_no_emsg"] = 'please valid a Contact number';
$lang["contact_input_no_plac"] = 'Enter Contact Number';
$lang["contact_type"] = 'Type';
$lang["contact_msg"] = 'Message';
$lang["contact_input_msg_emsg"] = 'You have not given a min 5 chars';
$lang["contact_input_msg_plac"] = 'Enter  Message';

