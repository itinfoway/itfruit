<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Controller extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->ch_login();
    }

    public function ch_login() {
        $directory = $this->router->directory;
        $class = $this->router->class;
        $method = $this->router->method;
        $dir_c = explode("/", $directory);
        if ($dir_c[0] == "admin") {
            if ($this->session->has_userdata("admin_login")) {
                if ($class == "login") {
                    redirect("admin/welcome");
                }
            } else {
                if ($class != "login") {
                    redirect("admin/login");
                }
            }
        }
    }

    public function display($view, $data = array()) {
        $directory = $this->router->directory;
        $class = $this->router->class;
        $method = $this->router->method;
        $dir_c = explode("/", $directory);
        //form help
        if ($method == "add" || $method == "edit") {
            $this->load->helper('form');
        }
        //header
        if ($dir_c[0] == "admin") {
            $this->load->view("admin/include/header");
        } else {
            $this->load->view("include/header");
        }
        //view
        $this->load->view($directory . "$class/" . $view, $data);
        //footer
        if ($dir_c[0] == "admin") {
            $this->load->view("admin/include/footer");
        } else {
            $this->load->view("include/footer");
        }
    }

}
