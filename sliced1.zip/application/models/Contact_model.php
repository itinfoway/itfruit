<?php

defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * Description of Faq_model
 * https://itinfoway.com
 * @author Admin
 */
class CONTACT_model extends CI_Model {

   

    public function add($array) {
        $this->db->trans_start();
        $this->db->insert(CONTACT, $array);
        $data = $this->db->insert_id();
        $this->db->trans_complete();
        return $data;
    }

   

    

}
