<?php
/**
 * Description of index
 * https://itinfoway.com
 * @author Admin
 */
$fromFname = [
    'type' => 'text',
    "name" => "fname",
    'class' => 'form-control',
    "data-validation"=>"length",
    "data-validation-length"=>"1-6",
    "data-validation-error-msg"=>$this->lang->line("user_input_fname_emsg"),
    'id' => "fname",
    "placeholder" => $this->lang->line("user_input_fname_plac"),
    'value' => isset($fname) ? $fname : "",
];
$fromLname = [
    'type' => 'text',
    "name" => "lname",
    'class' => 'form-control',
    "data-validation"=>"length",
    "data-validation-length"=>"1-5",
    "data-validation-error-msg"=>$this->lang->line("user_input_lname_emsg"),
    'id' => "lname",
    "placeholder" => $this->lang->line("user_input_lname_plac"),
    'value' => isset($lname) ? $lname : "",
];
$fromUname = [
    'type' => 'text',
    "name" => "username",
    'class' => 'form-control',
    "data-validation"=>"length,unique,alphanumeric",
    "data-validation-length"=>"min5",
    "data-validation-error-msg"=>$this->lang->line("user_input_name_emsg"),
    'id' => "username",
    "placeholder" => $this->lang->line("user_input_name_plac"),
    'value' => isset($username) ? $username : "",
];
$fromEmail = [
    'type' => 'text',
    "name" => "email",
    'class' => 'form-control',
    "data-validation"=>"length,email",
    "data-validation-length"=>"max255",
    "data-validation-error-msg"=>$this->lang->line("user_input_email_emsg"),
    'id' => "email",
    "placeholder" => $this->lang->line("user_input_email_plac"),
    'value' => isset($email) ? $email : "",
];
$fromNumber = [
    'type' => 'number',
    "name" => "mobile",
    'class' => 'form-control',
    "data-validation"=>"length",
    "data-validation-length"=>"min10",
    "data-validation-error-msg"=>$this->lang->line("user_input_no_emsg"),
    'id' => "mobile",
    "placeholder" => $this->lang->line("user_input_no_plac"),
    'value' => isset($mobile) ? $mobile : "",
];
$fromPassword = [
    'type' => 'password',
    "name" => "password",
    'class' => 'form-control',
    "data-validation"=>"length,confirmation",
    "data-validation-length"=>"min8",
    "data-validation-error-msg-confirmation"=>$this->lang->line("user_input_cpsw_emsg"),
    "data-validation-error-msg-length"=>$this->lang->line("user_input_psw_emsg"),
    'id' => "password",
    "placeholder" => $this->lang->line("user_input_psw_plac"),
];

$fromCpassword = [
    'type' => 'password',
    "name" => "password_confirmation",
    'class' => 'form-control',
    "data-validation"=>"length",
    "data-validation-length"=>"min8",
  "data-validation-error-msg"=>$this->lang->line("user_input_psw_emsg"),
    'id' => "cpassword",
    "placeholder" => $this->lang->line("user_input_psw_plac"),
    'value' => isset($cpassword) ? $cpassword : "",
];


?>
<div class="row">
    <div class="col-md-12">
        <!-- general form elements disabled -->
        <div class="card card-info card-outline">
            <div class="card-header">
                <h3 class="card-title"><?=$this->lang->line("user_head")?></h3>
                <div class="card-tools">
                    <a href="<?=  base_url("admin/Users/")?>" class="btn btn-info btn-sm"><?=$this->lang->line("btn_list") ?></a>
                </div>
            </div>
            <!-- /.card-header --> 
            <?= form_open(); ?>
            <div class="card-body">
                <div class="form-group">
                    <label><?=$this->lang->line("user_fname") ?></label>
                    <?= form_input($fromFname); ?>
                </div>
                <div class="form-group">
                    <label><?=$this->lang->line("user_lname") ?></label>
                    <?= form_input($fromLname); ?>
                </div>
                <div class="form-group">
                    <label><?=$this->lang->line("user_name") ?></label>
                    <?= form_input($fromUname); ?>
                </div>
                 <div class="form-group">
                    <label><?=$this->lang->line("user_email") ?></label>
                    <?= form_input($fromEmail); ?>
                </div>
                <div class="form-group">
                    <label><?=$this->lang->line("user_no") ?></label>
                    <?= form_input($fromNumber); ?>
                </div>
                <div class="form-group">
                    <label><?=$this->lang->line("user_psw") ?></label>
                    <?= form_input($fromPassword); ?>
                </div>
                 <div class="form-group">
                    <label><?=$this->lang->line("user_psw1") ?></label>
                    <?= form_input($fromCpassword); ?>
                </div>
                <div class="form-group">
                    <label><?=$this->lang->line("user_flag") ?> <br/>
                    <label><input type="radio" name="flag" value="1" <?php echo  set_radio('active', '1', TRUE); ?> />active</label>
                    <label><input type="radio" name="flag" value="2" <?php echo  set_radio('deactive', '2'); ?> />deactive</label></label>
                </div>
               
            </div>
            <div class="card-footer">
                <button type="submit" class="btn btn-info"  id="submit" ><?=$this->lang->line("btn_save") ?></button>
                <button type="reset" class="btn btn-default float-right"><?=$this->lang->line("btn_reset") ?></button>
            </div>
            <?= form_close(); ?>
            <!-- /.card-body -->
        </div>
    </div>
</div>

<script src="//cdnjs.cloudflare.com/ajax/libs/jquery-form-validator/2.3.26/jquery.form-validator.min.js"></script>
<script>
  $.validate({
    modules : 'security'
  });
</script>
