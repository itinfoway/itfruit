<?php
/**
 * Description of index
 * https://itinfoway.com
 * @author Admin
 */
?>
<link href="<?= base_url("assert/admin/plugins/datatable/dataTables.bootstrap4.min.css") ?>" rel="stylesheet">
<div class="row">
    <div class="col-md-12">
        <!-- general form elements disabled -->
        <div class="card card-success card-outline">
            <div class="card-header">
                <h3 class="card-title"><?= $this->lang->line("user_head") ?></h3>
                <div class="card-tools">
                    <a href="<?= base_url("admin/Users/add") ?>" class="btn btn-success btn-sm"><?= $this->lang->line("btn_add") ?></a>
                </div>
            </div>
            <div class="card-body">
                <table id="user_table" class="table table-striped table-bordered" style="width:100%">
                    <thead>
                        <tr>
                            <th><?=$this->lang->line("user_fname") ?></th>
                            <th><?=$this->lang->line("user_lname") ?></th>
                            <th><?=$this->lang->line("user_name") ?></th>
                            <th><?=$this->lang->line("user_email") ?></th>
                            <th><?=$this->lang->line("user_no") ?></th>
                            <th><?=$this->lang->line("user_flag") ?></th>
                            <th><?=$this->lang->line("action") ?></th>
                        </tr>
                    </thead>
                </table>
            </div>
            <!-- /.card-body -->
        </div>
    </div>
</div>
<script src="<?= base_url("assert/admin/plugins/datatable/jquery.dataTables.min.js") ?>"></script>
<script src="<?= base_url("assert/admin/plugins/datatable/dataTables.bootstrap4.min.js") ?>"></script>
<script>
    $(document).ready(function () {
        var table = $('#user_table').DataTable({
            ajax: "<?= base_url("admin/Users/json") ?>",
            responsive: true,
            columns: [
                {"data": "fname"},
                {"data": "lname"},
                {"data": "username"},
                {"data": "email"},
                {"data": "mobile"},
                {"data": "flag",
                    render: function (data) {
                        var view="" ;
                        if(data==1){
                            view +='Active';
                        }else{
                           view += 'Deactive';
                        }
                        
                        
                        return view;
                    }},
                {"data": "id",
                    render: function (data, type, row) {
                        var view = '<a href="<?= base_url("admin/Users/edit/") ?>' + data + '" class="btn btn-success btn-sm"><i class="fas fa-edit"></i></a> ';
                        view += '<a href="<?= base_url("admin/Users/delete/") ?>' + data + '" class="btn btn-danger btn-sm"><i class="fas fa-trash-alt"></i></a> ';
                        return view;
                    }
                }
            ]
        });
    });
</script>
<script>
    var uniquename="";
    <?php if ($this->router->method=="edit") { ?>
        uniquename=$("input[name='username']").val(); 
        <?php
    } ?>
   $.extend({
        xResponse: function (data) {
            var d = null;
            $.ajax({
                url: "<?= base_url("admin/Users/jsonusername/") ?>" + encodeURIComponent(btoa(data)),
                type: 'GET',
                data:{username:encodeURIComponent(btoa(uniquename))},
                dataType: "json",
                async: false,
                success: function (respText) {
                    if (respText) {
                        d = false;
                    } else {
                        d = true;
                    }
                    return d;
                }
            });
            return d;
        }
    });
    $.formUtils.addValidator({
        name: 'unique',
        validatorFunction: function (value, $el, config, language, $form) {
            return $.xResponse(value);
        },
        errorMessage: 'this value already inserted',
        errorMessageKey: 'badEvenNumber'
    });

</script>
<script>
    var uniquename="";
    <?php if ($this->router->method=="edit") { ?>
        uniquename=$("input[name='email']").val(); 
        <?php
    } ?>
   $.extend({
        xResponsex: function (data) {
            var d = null;
            $.ajax({
                url: "<?= base_url("admin/Users/jsonemail/") ?>" + encodeURIComponent(btoa(data)),
                type: 'GET',
                data:{email:encodeURIComponent(btoa(uniquename))},
                dataType: "json",
                async: false,
                success: function (respText) {
                    if (respText) {
                        d = false;
                    } else {
                        d = true;
                    }
                    return d;
                }
            });
            return d;
        }
    });
    $.formUtils.addValidator({
        name: 'unique',
        validatorFunction: function (value, $el, config, language, $form) {
            return $.xResponsex(value);
        },
        errorMessage: 'this value already inserted',
        errorMessageKey: 'badEvenNumber'
    });

</script>
