<?php

/**
 * Description of index
 * https://itinfoway.com
 * @author Admin
 */
$fromQus = [
    'type' => 'text',
    "name" => "name",
    'class' => 'form-control',
    "data-validation" => "length",
    "data-validation-length" => "5-255",
    "data-validation-error-msg" => $this->lang->line("fruit_input_name_emsg"),
    'id' => "qus",
    "placeholder" => $this->lang->line("fruit_input_name_plac"),
    'value' => isset($data->name) ? $data->name : "",
];
?>

<div class="row">
    <div class="col-md-12">
        <!-- general form elements disabled -->
        <div class="card card-info card-outline">
            <div class="card-header">
                <h3 class="card-title"><?= $this->lang->line("fruit_head") ?></h3>
                <div class="card-tools">
                    <a href="<?= base_url("admin/setting/fruit/") ?>" class="btn btn-info btn-sm"><?= $this->lang->line("btn_list") ?></a>
                </div>
            </div>
            <!-- /.card-header -->
            <?= form_open_multipart(); ?>
            <div class="card-body">
                <div class="form-group">
                    <label><?= $this->lang->line("fruit_name_hed") ?></label>
                    <?= form_input($fromQus); ?>
                </div>
                <div class="form-group">
                    <label><?= $this->lang->line("fruit_vitamin_hed") ?></label>
                    <?= form_multiselect("vitamin_ids[]", $vitamin, isset($data->vitamin_ids) ? json_decode($data->vitamin_ids) : null, ["class" => "select2", "multiple" => "multiple", "style" => "width: 100%;", "data-placeholder" => $this->lang->line("fruit_select_vitamin_plac")]); ?>
                </div>
                <div class="form-group">
                    <label><?= $this->lang->line("fruit_img_hed") ?></label>
                    <div class="input-group">
                        <div class="custom-file">
                            <?= form_upload("img", isset($data->img) ? $data->img : "", ['class' => 'custom-file-input',  "data-validation" => "mime size", "data-validation-allowing" => "jpg, png, gif", "data-validation-max-size" => "500kb"]); ?>
                            <label class="custom-file-label" for="exampleInputFile">Choose file</label>
                        </div>
                    </div>
                </div>

            </div>
            <div class="card-footer">
                <button type="submit" class="btn btn-info"><?= $this->lang->line("btn_save") ?></button>
                <button type="reset" class="btn btn-default float-right"><?= $this->lang->line("btn_reset") ?></button>
            </div>
            <?= form_close(); ?>
            <!-- /.card-body -->
        </div>
    </div>
</div>
<!-- bs-custom-file-input -->
<script src="<?= base_url() ?>assert/admin/plugins/bs-custom-file-input/bs-custom-file-input.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery-form-validator/2.3.26/jquery.form-validator.min.js"></script>

<script>
    $.validate({
        modules: 'file'
    });
</script>
<script type="text/javascript">
    $(document).ready(function() {
        bsCustomFileInput.init();
    });
</script>