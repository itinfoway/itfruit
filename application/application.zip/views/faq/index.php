<?php

/**
 * Description of Users
 * https://itinfoway.com
 * @author Admin
 */
?>
<section>
    <div class="faq">
        <div class="faq-bg">
            <div class="faq-text">
                <h1>Frequently</h1>
                <h1>Asked Questions</h1>
                <p>NEED HELP?</p>
            </div>
        </div>
    </div>
</section>
<section>
    <div class="search-bar">
        <div class="container my-container">
            <div class="row">
                <div class="col-xs-1">
                    <img class="img-responsive" src="<?= base_url("assert/fontend/"); ?>img/search-icon.png">
                </div>
                <div class="col-xs-11 search-part">
                    <input type="text" placeholder="search here">
                    <img class="img-responsive line" src="<?= base_url("assert/fontend/"); ?>img/faq-line.png">
                </div>
            </div>
        </div>
</section>
<section>
    <div class="que-part">
        <h4>frequently asked questions</h4>

        <button class="accordion"><img id="plus-icon" class="img-responsive" src="<?= base_url("assert/fontend/"); ?>img/plus-icon.png"><img id="minus-icon" class="img-responsive" src="<?= base_url("assert/fontend/"); ?>img/minus-icon.png">
            <p>What are the services that you provide?</p>
        </button>
        <div class="panel">
            <p>| We provide ala-carte delivery and subscription based delivery.</p>
        </div>

        <img class="img-responsive line" src="<?= base_url("assert/fontend/"); ?>img/faq-line.png" width="100%">

        <button class="accordion"><img id="plus-icon" class="img-responsive" src="<?= base_url("assert/fontend/"); ?>img/plus-icon.png"><img id="minus-icon" class="img-responsive" src="<?= base_url("assert/fontend/"); ?>img/minus-icon.png">
            <p>What are the services that you provide?</p>
        </button>
        <div class="panel">
            <p>| We provide ala-carte delivery and subscription based delivery.</p>
        </div>

        <img class="img-responsive line" src="<?= base_url("assert/fontend/"); ?>img/faq-line.png" width="100%">

        <button class="accordion"><img id="plus-icon" class="img-responsive" src="<?= base_url("assert/fontend/"); ?>img/plus-icon.png"><img id="minus-icon" class="img-responsive" src="<?= base_url("assert/fontend/"); ?>img/minus-icon.png">
            <p>Is the any minimum purchase for delivery?</p>
        </button>
        <div class="panel">
            <p>| We provide ala-carte delivery and subscription based delivery.</p>
        </div>

        <img class="img-responsive line" src="<?= base_url("assert/fontend/"); ?>img/faq-line.png" width="100%">

        <button class="accordion"><img id="plus-icon" class="img-responsive" src="<?= base_url("assert/fontend/"); ?>img/plus-icon.png"><img id="minus-icon" class="img-responsive" src="<?= base_url("assert/fontend/"); ?>img/minus-icon.png">
            <p>What are your delivery time slots?</p>
        </button>
        <div class="panel">
            <p>| We provide ala-carte delivery and subscription based delivery.</p>
        </div>

        <img class="img-responsive line" src="<?= base_url("assert/fontend/"); ?>img/faq-line.png" width="100%">

        <button class="accordion"><img id="plus-icon" class="img-responsive" src="<?= base_url("assert/fontend/"); ?>img/plus-icon.png"><img id="minus-icon" class="img-responsive" src="<?= base_url("assert/fontend/"); ?>img/minus-icon.png">
            <p>What are the mode of payments?</p>
        </button>
        <div class="panel">
            <p>| We provide ala-carte delivery and subscription based delivery.</p>
        </div>

        <img class="img-responsive line" src="<?= base_url("assert/fontend/"); ?>img/faq-line.png" width="100%">

        <button class="accordion"><img id="plus-icon" class="img-responsive" src="<?= base_url("assert/fontend/"); ?>img/plus-icon.png"><img id="minus-icon" class="img-responsive" src="<?= base_url("assert/fontend/"); ?>img/minus-icon.png">
            <p>Is the any minimum purchase for delivery?</p>
        </button>
        <div class="panel">
            <p>| We provide ala-carte delivery and subscription based delivery.</p>
        </div>

        <img class="img-responsive line" src="<?= base_url("assert/fontend/"); ?>img/faq-line.png" width="100%">

        <button class="accordion"><img id="plus-icon" class="img-responsive" src="<?= base_url("assert/fontend/"); ?>img/plus-icon.png"><img id="minus-icon" class="img-responsive" src="<?= base_url("assert/fontend/"); ?>img/minus-icon.png">
            <p>What are your delivery days?</p>
        </button>
        <div class="panel">
            <p>| We provide ala-carte delivery and subscription based delivery.</p>
        </div>

        <img class="img-responsive line" src="<?= base_url("assert/fontend/"); ?>img/faq-line.png" width="100%">

        <button class="accordion"><img id="plus-icon" class="img-responsive" src="<?= base_url("assert/fontend/"); ?>img/plus-icon.png"><img id="minus-icon" class="img-responsive" src="<?= base_url("assert/fontend/"); ?>img/minus-icon.png">
            <p>How fresh are your fruits?</p>
        </button>
        <div class="panel">
            <p>| We provide ala-carte delivery and subscription based delivery.</p>
        </div>

        <img class="img-responsive line" src="<?= base_url("assert/fontend/"); ?>img/faq-line.png" width="100%">

        <button class="accordion"><img id="plus-icon" class="img-responsive" src="<?= base_url("assert/fontend/"); ?>img/plus-icon.png"><img id="minus-icon" class="img-responsive" src="<?= base_url("assert/fontend/"); ?>img/minus-icon.png">
            <p>What if the fruits delivered are damaged? </p>
        </button>
        <div class="panel">
            <p>| We provide ala-carte delivery and subscription based delivery.</p>
        </div>

        <img class="img-responsive line" src="<?= base_url("assert/fontend/"); ?>img/faq-line.png" width="100%">

        <button class="accordion"><img id="plus-icon" class="img-responsive" src="<?= base_url("assert/fontend/"); ?>img/plus-icon.png"><img id="minus-icon" class="img-responsive" src="<?= base_url("assert/fontend/"); ?>img/minus-icon.png">
            <p>What if it rains/thunderstorm?</p>
        </button>
        <div class="panel">
            <p>| We provide ala-carte delivery and subscription based delivery.</p>
        </div>

        <img class="img-responsive line" src="<?= base_url("assert/fontend/"); ?>img/faq-line.png" width="100%">

        <button class="accordion"><img id="plus-icon" class="img-responsive" src="<?= base_url("assert/fontend/"); ?>img/plus-icon.png"><img id="minus-icon" class="img-responsive" src="<?= base_url("assert/fontend/"); ?>img/minus-icon.png">
            <p>What if it rains/thunderstorm the whole day?</p>
        </button>
        <div class="panel">
            <p>| We provide ala-carte delivery and subscription based delivery.</p>
        </div>

        <img class="img-responsive line" src="<?= base_url("assert/fontend/"); ?>img/faq-line.png" width="100%">

        <button class="accordion"><img id="plus-icon" class="img-responsive" src="<?= base_url("assert/fontend/"); ?>img/plus-icon.png"><img id="minus-icon" class="img-responsive" src="<?= base_url("assert/fontend/"); ?>img/minus-icon.png">
            <p>What if I'm travelling during the delivery?</p>
        </button>
        <div class="panel">
            <p>| We provide ala-carte delivery and subscription based delivery.</p>
        </div>

        <img class="img-responsive line" src="<?= base_url("assert/fontend/"); ?>img/faq-line.png" width="100%">

        <button class="accordion"><img id="plus-icon" class="img-responsive" src="<?= base_url("assert/fontend/"); ?>img/plus-icon.png"><img id="minus-icon" class="img-responsive" src="<?= base_url("assert/fontend/"); ?>img/minus-icon.png">
            <p>I will be travelling and may not be able to finish my credit before its expiry. Will I be able to postpone my meals until I return?</p>
        </button>
        <div class="panel">
            <p>| We provide ala-carte delivery and subscription based delivery.</p>
        </div>

        <img class="img-responsive line" src="<?= base_url("assert/fontend/"); ?>img/faq-line.png" width="100%">

        <button class="accordion"><img id="plus-icon" class="img-responsive" src="<?= base_url("assert/fontend/"); ?>img/plus-icon.png"><img id="minus-icon" class="img-responsive" src="<?= base_url("assert/fontend/"); ?>img/minus-icon.png">
            <p>What if I want to order a large amount?</p>
        </button>
        <div class="panel">
            <p>| We provide ala-carte delivery and subscription based delivery.</p>
        </div>

        <img class="img-responsive line" src="<?= base_url("assert/fontend/"); ?>img/faq-line.png" width="100%">

        <button class="accordion"><img id="plus-icon" class="img-responsive" src="<?= base_url("assert/fontend/"); ?>img/plus-icon.png"><img id="minus-icon" class="img-responsive" src="<?= base_url("assert/fontend/"); ?>img/minus-icon.png">
            <p>Why are some of the fruits not available in your menu? </p>
        </button>
        <div class="panel">
            <p>| We provide ala-carte delivery and subscription based delivery.</p>
        </div>

        <img class="img-responsive line" src="<?= base_url("assert/fontend/"); ?>img/faq-line.png" width="100%">

        <button class="accordion"><img id="plus-icon" class="img-responsive" src="<?= base_url("assert/fontend/"); ?>img/plus-icon.png"><img id="minus-icon" class="img-responsive" src="<?= base_url("assert/fontend/"); ?>img/minus-icon.png">
            <p>Feel free to email slicedsg @gmail.com or chat with us for more information on offshore postal areas.</p>
        </button>
        <div class="panel">
            <p>| We provide ala-carte delivery and subscription based delivery.</p>
        </div>

        <img class="img-responsive line" src="<?= base_url("assert/fontend/"); ?>img/faq-line.png" width="100%">

        <button class="accordion"><img id="plus-icon" class="img-responsive" src="<?= base_url("assert/fontend/"); ?>img/plus-icon.png"><img id="minus-icon" class="img-responsive" src="<?= base_url("assert/fontend/"); ?>img/minus-icon.png">
            <p>What if I have a suggestion or my queries are not in this FAQ?</p>
        </button>
        <div class="panel">
            <p>| We provide ala-carte delivery and subscription based delivery.</p>
        </div>
    </div>
</section>