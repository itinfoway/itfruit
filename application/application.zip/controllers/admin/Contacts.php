<?php

defined('BASEPATH') or exit('No direct script access allowed');
require_once APPPATH . "core/Controller.php";

/**
 * Description of Setting
 * https://itinfoway.com
 * @author Admin
 */
class Contacts extends Controller
{

    public function __construct()
    {
        parent::__construct();
        $this->load->model("Contact_model");
    }

    public function index()
    {
        $this->display("index");
    }

    public function add()
    {
        if ($this->input->server('REQUEST_METHOD') == 'POST') {
            $capArray = $this->input->post();
            $capArray["ip_address"]=$this->input->ip_address();
            $data = $this->Contact_model->add($capArray);
            print_r($data);
            if (!empty($data)) {
                redirect("admin/Contacts/add");
            } else {
                redirect("admin/Contacts/add");
            }
        }
        $this->display('add');
    }

    public function edit($id)
    {
        if ($this->input->server('REQUEST_METHOD') == 'POST') {
            $capArray = $this->input->post();
            $data = $this->Contact_model->edit($capArray, $id);
            if (!empty($data)) {
                redirect("admin/Contacts/add");
            } else {
                redirect("admin/Contacts/add");
            }
        } else {
            $data = $this->Contact_model->view($id);
        }
        $this->display("add", $data[0]);
    }

    public function delete($id)
    {
        $data = $this->Contact_model->delete($id);
        if (!empty($data)) {
            redirect("admin/Contacts/index");
        } else {
            redirect("admin/Contacts/index");
        }
    }

    public function json($name = null)
    {
        if (is_null($name)) {
            $select = !empty($this->input->get("select")) ? $this->input->get("select") : "*";
            $data["contactus"]["data"] = $this->Contact_model->view(null, $select);
        } else {
            $name = base64_decode(urldecode($name));
            $old = $this->input->get("name");
            $data["contactus"] = $this->Contact_model->findname($name, base64_decode(urldecode($old)));
        }
        if ($data["contactus"] == 0) {
            $data["contactus"] = FALSE;
        } else if (!isset($data["contactus"]["data"]) && $data["contactus"] >= 1) {
            $data["contactus"] = TRUE;
        }
        return $this->output
            ->set_content_type('application/json')
            ->set_status_header(200) // Return status
            ->set_output(json_encode($data["contactus"]));
    }
}
