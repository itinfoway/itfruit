<?php

defined('BASEPATH') or exit('No direct script access allowed');
require_once APPPATH . "core/Controller.php";

/**
 * Description of Setting
 * https://itinfoway.com
 * @author Admin
 */
class Address extends Controller
{

    public function __construct()
    {
        parent::__construct();
        $this->load->model("User_model");
    }

    public function index()
    {
        $this->display("index");
    }

    public function add()
    {
        if ($this->input->server('REQUEST_METHOD') == 'POST') {
            $capArray = $this->input->post();
            unset($capArray["password_confirmation"]);
            $data = $this->User_model->add($capArray);
            print_r($data);
            if (!empty($data)) {
                redirect("admin/Address/add");
            } else {
                redirect("admin/Address/add");
            }
        }
        $this->display('add');
    }

    public function edit($id)
    {
        if ($this->input->server('REQUEST_METHOD') == 'POST') {
            $capArray = $this->input->post();
            unset($capArray["password_confirmation"]);
            $data = $this->User_model->edit($capArray, $id);
            if (!empty($data)) {
                redirect("admin/Users/add");
            } else {
                redirect("admin/Users/add");
            }
        } else {
            $data = $this->User_model->view($id);
        }
        $this->display("add", $data[0]);
    }

    public function delete($id)
    {
        $data = $this->User_model->delete($id);
        if (!empty($data)) {
            redirect("admin/Users/index");
        } else {
            redirect("admin/Users/index");
        }
    }
    public function jsonemail($name = null)
    {
        $name = base64_decode(urldecode($name));
        $old = $this->input->get("name");
        $data["users"] = $this->User_model->findemail($name, base64_decode(urldecode($old)));
        if ($data["users"] == 0) {
            $data["users"] = FALSE;
        } else if (!isset($data["users"]["data"]) && $data["users"] >= 1) {
            $data["users"] = TRUE;
        }
        return $this->output
            ->set_content_type('application/json')
            ->set_status_header(200) // Return status
            ->set_output(json_encode($data["users"]));
    }
    public function jsonusername($name = null)
    {
        $name = base64_decode(urldecode($name));
        $old = $this->input->get("name");
        $data["users"] = $this->User_model->finduname($name, base64_decode(urldecode($old)));
        if ($data["users"] == 0) {
            $data["users"] = FALSE;
        } else if (!isset($data["users"]["data"]) && $data["users"] >= 1) {
            $data["users"] = TRUE;
        }
        return $this->output
            ->set_content_type('application/json')
            ->set_status_header(200) // Return status
            ->set_output(json_encode($data["users"]));
    }
    public function json($name = null)
    {
        if (is_null($name)) {
            $select = !empty($this->input->get("select")) ? $this->input->get("select") : "*";
            $data["users"]["data"] = $this->User_model->view(null, $select);
        } else {
            $name = base64_decode(urldecode($name));
            $old = $this->input->get("name");
            $data["users"] = $this->User_model->findname($name, base64_decode(urldecode($old)));
        }
        if ($data["users"] == 0) {
            $data["users"] = FALSE;
        } else if (!isset($data["users"]["data"]) && $data["users"] >= 1) {
            $data["users"] = TRUE;
        }
        return $this->output
            ->set_content_type('application/json')
            ->set_status_header(200) // Return status
            ->set_output(json_encode($data["users"]));
    }
}
