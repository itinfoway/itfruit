<?php

defined('BASEPATH') or exit('No direct script access allowed');
require_once APPPATH . "core/Controller.php";

/**
 * Description of Setting
 * https://itinfoway.com
 * @author Admin
 */
class Fruit extends Controller
{

    public function __construct()
    {
        parent::__construct();
        $this->load->model("fruit_model");
        $this->load->model("vitamin_model");
    }

    public function index()
    {
        $this->display("index");
    }

    public function add()
    {
        if ($this->input->server('REQUEST_METHOD') == 'POST') {
            $capArray["name"] = $this->input->post("name");
            $capArray["vitamin_ids"] = json_encode($this->input->post("vitamin_ids"));
            $config['upload_path']          = './assert/fruit/';
            $config['allowed_types']        = 'gif|jpg|png|jpeg';
            $config['max_size']             = 500;
            $this->load->library('upload', $config);
            if (!$this->upload->do_upload('img')) {
                $this->session->set_userdata('error', $this->upload->display_errors());
                print_r($this->upload->display_errors());
            } else {
                $capArray["img"] = $this->upload->data('file_name');
            }
            $data = $this->fruit_model->add($capArray);
            print_r($data);
            if (!empty($data)) {
                redirect("admin/setting/fruit/add");
            } else {
                redirect("admin/setting/fruit/add");
            }
        }
        $vitamin = $this->vitamin_model->view();
        $data = array();
        foreach ($vitamin as $v) {
            $data["vitamin"][$v->id] = $v->name;
        }
        $this->display('add', $data);
    }

    public function edit($id)
    {
        if ($this->input->server('REQUEST_METHOD') == 'POST') {
            $capArray = $this->input->post();
            $data = $this->fruit_model->edit($capArray, $id);
            if (!empty($data)) {
                redirect("admin/setting/fruit/add");
            } else {
                redirect("admin/setting/fruit/add");
            }
        } else {
            $data = $this->fruit_model->view($id);
            $data["data"]=$data[0];
        }
        $vitamin = $this->vitamin_model->view();
        
        foreach ($vitamin as $v) {
            $data["vitamin"][$v->id] = $v->name;
        }
        $this->display("add", $data);
    }

    public function delete($id)
    {
        $data = $this->fruit_model->delete($id);
        if (!empty($data)) {
            redirect("admin/setting/fruit/add");
        } else {
            redirect("admin/setting/fruit/add");
        }
    }

    public function json($name = null)
    {
        if (is_null($name)) {
            $select = !empty($this->input->get("select")) ? $this->input->get("select") : "*";
            $data["fruit"]["data"] = $this->fruit_model->view(null, $select);
        } else {
            $name = base64_decode(urldecode($name));
            $old = $this->input->get("name");
            $data["fruit"] = $this->fruit_model->findname($name, base64_decode(urldecode($old)));
        }
        if ($data["fruit"] == 0) {
            $data["fruit"] = FALSE;
        } else if (!isset($data["fruit"]["data"]) && $data["fruit"] >= 1) {
            $data["fruit"] = TRUE;
        }
        return $this->output
            ->set_content_type('application/json')
            ->set_status_header(200) // Return status
            ->set_output(json_encode($data["fruit"]));
    }
}
